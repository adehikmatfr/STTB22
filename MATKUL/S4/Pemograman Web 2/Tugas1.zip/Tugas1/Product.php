<?php
class Product {
    // access modifire
    public $nama = "Product Sharp";
    public $merek = "Sharp";
    protected $stock = 10;

    // enkapsulation
    public function Info() {
        return "Sisa Stock: ".$this->stock;
    }
}