<?php
class Television extends Electronic {
    private $type;
    public function __construct(string $nama,string $merek,int $stock, string $type) {
        parent::__construct($nama, $merek, $stock);
        $this->type = $type;
    }

    public function Info() {
        return parent::Info()." Type ". $this->type;
    }
}