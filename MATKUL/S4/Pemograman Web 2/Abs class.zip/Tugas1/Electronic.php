
<?php
class Electronic extends Product {
     public function __construct(string $nama,string $merek,int $stock) {
        $this->nama = "Product Electronic ". $nama;
        $this->merek = $merek;
        $this->stock = $stock;
     }

    // overrieding func
    public function info() {
        return "nama product ". $this->nama." marek product ".$this->merek;
    }
}