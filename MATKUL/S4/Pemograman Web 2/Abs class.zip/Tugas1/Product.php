<?php

abstract class Product {
    // access modifire
    public $nama;
    public $merek;
    protected $stock;

    // enkapsulation
    public abstract function info();
}