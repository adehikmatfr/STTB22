<?php
$host="localhost";
$username="root";
$password="";
$database="adehikmatfr-pertemuan-11";
$conn = mysqli_connect($host, $username, $password, $database) or die("invalid connection");
