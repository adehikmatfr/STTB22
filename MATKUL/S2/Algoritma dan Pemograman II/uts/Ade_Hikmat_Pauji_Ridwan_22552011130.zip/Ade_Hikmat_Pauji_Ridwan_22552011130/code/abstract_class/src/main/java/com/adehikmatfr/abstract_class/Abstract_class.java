/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.adehikmatfr.abstract_class;

/**
 *
 * @author Administrator
 */
public class Abstract_class {

    public static void main(String[] args) {
        InputForm.main(args);
    }
}
