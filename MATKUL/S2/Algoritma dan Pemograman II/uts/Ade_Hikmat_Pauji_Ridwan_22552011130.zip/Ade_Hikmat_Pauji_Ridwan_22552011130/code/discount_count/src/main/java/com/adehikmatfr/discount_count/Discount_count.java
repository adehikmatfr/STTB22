/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.adehikmatfr.discount_count;

/**
 *
 * @author Administrator
 */
public class Discount_count {

    public static void main(String[] args) {
        InputForm.main(args);
    }
}
