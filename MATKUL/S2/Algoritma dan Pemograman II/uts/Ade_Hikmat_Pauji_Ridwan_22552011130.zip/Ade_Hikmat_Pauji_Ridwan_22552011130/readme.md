Java Version 19.0.2 2023-01-17

Version Netbeans Apache NetBeans IDE 17

Build Tools maven
